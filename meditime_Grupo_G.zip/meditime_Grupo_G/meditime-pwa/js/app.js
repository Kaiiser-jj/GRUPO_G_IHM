/* =========================================================
   MediTime · PWA académica (HTML + CSS + Bootstrap 5.3 + JS)
   - Datos simulados en localStorage (sin backend ni BD)
   - Login/registro simulados: NO es seguridad real
   - Alarma: Web Audio + Notification + Wake Lock + vibración
   ========================================================= */
(() => {
  'use strict';

  /* ---------- Utilidades ---------- */
  const LS_KEY = 'meditime_v1';
  const $ = (s, r = document) => r.querySelector(s);
  const $$ = (s, r = document) => [...r.querySelectorAll(s)];
  const pad = n => String(n).padStart(2, '0');
  const ymd = d => `${d.getFullYear()}-${pad(d.getMonth() + 1)}-${pad(d.getDate())}`;
  const hm = d => `${pad(d.getHours())}:${pad(d.getMinutes())}`;
  const parseYmd = s => { const [y, m, d] = s.split('-').map(Number); return new Date(y, m - 1, d); };
  const esc = s => String(s).replace(/[&<>"']/g, c => ({ '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c]));
  const MESES = ['Enero', 'Febrero', 'Marzo', 'Abril', 'Mayo', 'Junio', 'Julio', 'Agosto', 'Septiembre', 'Octubre', 'Noviembre', 'Diciembre'];
  const DIAS = ['Domingo', 'Lunes', 'Martes', 'Miércoles', 'Jueves', 'Viernes', 'Sábado'];
  const DIAS_CORTO = ['LUN', 'MAR', 'MIÉ', 'JUE', 'VIE', 'SÁB', 'DOM'];
  const fechaLarga = d => `${DIAS[d.getDay()]}, ${d.getDate()} de ${MESES[d.getMonth()]}`;

  /* ---------- Estado persistente ---------- */
  function estadoInicial() {
    return { cuentas: {}, sesion: null, dosis: {}, tomas: {}, alarmadas: {}, posp: {}, ajustes: { tema: 'dark', segundoPlano: true, pantalla: true } };
  }
  function cargar() {
    try {
      const e = JSON.parse(localStorage.getItem(LS_KEY));
      if (e && e.cuentas) {
        const base = estadoInicial();
        return { ...base, ...e, ajustes: { ...base.ajustes, ...(e.ajustes || {}) } };
      }
    } catch (_) { /* almacenamiento no disponible */ }
    return estadoInicial();
  }
  let estado = cargar();
  function guardar() { try { localStorage.setItem(LS_KEY, JSON.stringify(estado)); } catch (_) { /* ignorar */ } }

  // Limpia marcas de alarma antiguas (más de 14 días)
  (function podar() {
    const limite = ymd(new Date(Date.now() - 14 * 86400000));
    for (const k of Object.keys(estado.alarmadas)) { if (k.split('|')[1] < limite) delete estado.alarmadas[k]; }
    guardar();
  })();

  async function hash(txt) {
    try {
      if (window.crypto && crypto.subtle) {
        const b = await crypto.subtle.digest('SHA-256', new TextEncoder().encode('meditime:' + txt));
        return [...new Uint8Array(b)].map(x => x.toString(16).padStart(2, '0')).join('');
      }
    } catch (_) { /* sigue al respaldo */ }
    return 'b64:' + btoa(unescape(encodeURIComponent('meditime:' + txt)));
  }

  // Cuenta de prueba precargada
  (async function sembrarDemo() {
    if (!estado.cuentas['demo@meditime.com']) {
      estado.cuentas['demo@meditime.com'] = { cedula: '1805480520', edad: 24, nombres: 'Cuenta', apellidos: 'Demo', email: 'demo@meditime.com', pass: await hash('Demo1234') };
      guardar();
    }
  })();

  /* ---------- Datos de dosis ---------- */
  const dosisUsuario = () => (estado.dosis[estado.sesion] = estado.dosis[estado.sesion] || []);
  const tomasUsuario = () => (estado.tomas[estado.sesion] = estado.tomas[estado.sesion] || {});
  function dosisDe(fecha) {
    if (!estado.sesion) return [];
    return dosisUsuario()
      .filter(d => (d.repetir === 'diaria' ? fecha >= d.fecha : d.fecha === fecha))
      .sort((a, b) => a.hora.localeCompare(b.hora));
  }
  const tomada = (d, f) => tomasUsuario()[d.id + '|' + f];
  function estadoDosis(d, fecha, ahora = new Date()) {
    if (tomada(d, fecha)) return 'tomada';
    const hoy = ymd(ahora);
    if (fecha > hoy) return 'pendiente';
    if (fecha < hoy) return 'omitida';
    return d.hora <= hm(ahora) ? 'atrasada' : 'pendiente';
  }
  const ETIQUETA = { tomada: 'Tomada', pendiente: 'Pendiente', atrasada: 'Atrasada', omitida: 'Omitida' };

  /* ---------- Mensajes ---------- */
  function toast(msg, error = false) {
    const el = document.createElement('div');
    el.className = 'toast mt-toast' + (error ? ' err' : '');
    el.setAttribute('role', 'status');
    el.innerHTML = `<div class="toast-body">${esc(msg)}</div>`;
    $('#toasts').appendChild(el);
    const t = new bootstrap.Toast(el, { delay: 4000 });
    el.addEventListener('hidden.bs.toast', () => el.remove());
    t.show();
  }
  function setError(input, msg) {
    input.classList.add('is-invalid');
    const fb = document.getElementById(input.id + 'E') || input.parentElement.querySelector('.invalid-feedback');
    if (fb) fb.textContent = msg;
  }
  function limpiarErrores(form) { $$('.is-invalid', form).forEach(i => i.classList.remove('is-invalid')); }
  document.addEventListener('input', e => { if (e.target.classList && e.target.classList.contains('is-invalid')) e.target.classList.remove('is-invalid'); });
  function enfocarPrimerError(form) { const el = $('.is-invalid', form); if (el) el.focus(); }

  /* ---------- Tema y modo por edad ---------- */
  function aplicarTema(t) {
    document.documentElement.setAttribute('data-bs-theme', t);
    const m = $('meta[name="theme-color"]');
    if (m) m.setAttribute('content', t === 'dark' ? '#090D16' : '#EEF2F7');
  }
  function modoEdad(edad) {
    if (edad >= 60) return { clase: 'ui-grande', txt: '60+: Ampliado' };
    if (edad >= 31) return { clase: 'ui-comodo', txt: '31-59: Cómodo' };
    return { clase: 'ui-normal', txt: '10-30: Normal' };
  }
  function aplicarModoEdad(edad) {
    const h = document.documentElement;
    h.classList.remove('ui-normal', 'ui-comodo', 'ui-grande');
    h.classList.add(edad ? modoEdad(edad).clase : 'ui-normal');
  }

  /* ---------- Router (SPA con hash) ---------- */
  const RUTAS = { '': 'inicio', '/': 'inicio', '/registro': 'registro', '/login': 'login', '/hoy': 'hoy', '/calendario': 'calendario', '/ajustes': 'ajustes' };
  const PRIVADAS = new Set(['hoy', 'calendario', 'ajustes']);
  const TITULOS = { inicio: 'Bienvenida', registro: 'Crear cuenta', login: 'Iniciar sesión', hoy: 'Hoy', calendario: 'Calendario', ajustes: 'Ajustes' };
  let rutaActual = 'inicio';
  let avisoLogin = null; // {tipo, texto}

  function irA(hash) { if (location.hash === hash) ruta(); else location.hash = hash; }
  function ruta() {
    const h = location.hash.replace(/^#/, '');
    let nombre = RUTAS[h] || 'inicio';
    if (PRIVADAS.has(nombre) && !estado.sesion) {
      avisoLogin = { tipo: 'error', texto: 'Inicia sesión para acceder a tu panel.' };
      nombre = 'login'; history.replaceState(null, '', '#/login');
    } else if ((nombre === 'login' || nombre === 'registro') && estado.sesion) {
      nombre = 'hoy'; history.replaceState(null, '', '#/hoy');
    }
    rutaActual = nombre;
    $$('[data-ruta]').forEach(s => s.classList.toggle('d-none', s.dataset.ruta !== nombre));
    $$('[data-auth]').forEach(s => s.classList.toggle('d-none', (s.dataset.auth === 'true') !== !!estado.sesion));
    $$('[data-nav]').forEach(a => { const on = a.dataset.nav === nombre; a.classList.toggle('activo', on); on ? a.setAttribute('aria-current', 'page') : a.removeAttribute('aria-current'); });
    document.title = `${TITULOS[nombre]} · MediTime`;
    if (nombre === 'login') mostrarAvisoLogin();
    renderVista();
    window.scrollTo(0, 0);
    $('#contenido').focus({ preventScroll: true });
  }
  function renderVista() {
    if (rutaActual === 'hoy') renderHoy();
    else if (rutaActual === 'calendario') renderCalendario();
    else if (rutaActual === 'ajustes') renderAjustes();
    actualizarAvisoAudio();
  }

  /* ---------- REGISTRO ---------- */
  const EMAIL_RE = /^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/;
  function requisitos(p) { return { len: p.length >= 8, may: /[A-Z]/.test(p), min: /[a-z]/.test(p), num: /\d/.test(p) }; }
  function actualizarRequisitos() {
    const p = $('#rPass').value, c = $('#rPass2').value, r = requisitos(p);
    $$('#reqPass li').forEach(li => { const ok = r[li.dataset.req]; li.classList.toggle('ok', ok); $('.mt-req-ico', li).textContent = ok ? '✓' : '✗'; });
    const m = $('#msgCoincide');
    if (!c) { m.textContent = ''; m.className = 'mt-msg'; }
    else if (p === c) { m.textContent = '✓ Las contraseñas coinciden'; m.className = 'mt-msg ok'; }
    else { m.textContent = '✗ Las contraseñas no coinciden'; m.className = 'mt-msg mal'; }
  }
  function actualizarBadgeEdad() {
    const v = parseInt($('#rEdad').value, 10), b = $('#badgeEdad');
    if (Number.isFinite(v) && v >= 10 && v <= 120) { b.textContent = modoEdad(v).txt; b.classList.remove('d-none'); }
    else b.classList.add('d-none');
  }
  $('#rPass').addEventListener('input', actualizarRequisitos);
  $('#rPass2').addEventListener('input', actualizarRequisitos);
  $('#rEdad').addEventListener('input', actualizarBadgeEdad);

  $('#formRegistro').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target; limpiarErrores(f);
    const v = id => $('#' + id).value.trim();
    const cedula = v('rCedula'), edad = parseInt($('#rEdad').value, 10), nombres = v('rNombres'), apellidos = v('rApellidos');
    const email = v('rEmail').toLowerCase(), pass = $('#rPass').value, pass2 = $('#rPass2').value;
    let ok = true; const mal = (id, m) => { setError($('#' + id), m); ok = false; };

    if (!cedula) mal('rCedula', 'Escribe tu cédula.');
    else if (!/^\d{10}$/.test(cedula)) mal('rCedula', 'La cédula debe tener exactamente 10 dígitos numéricos.');
    if (!$('#rEdad').value) mal('rEdad', 'Escribe tu edad.');
    else if (!Number.isInteger(edad) || edad < 10 || edad > 120) mal('rEdad', 'Edad válida entre 10 y 120.');
    if (!nombres) mal('rNombres', 'Completa este campo.');
    else if (nombres.length < 2) mal('rNombres', 'Escribe al menos 2 letras.');
    if (!apellidos) mal('rApellidos', 'Completa este campo.');
    else if (apellidos.length < 2) mal('rApellidos', 'Escribe al menos 2 letras.');
    if (!email) mal('rEmail', 'Escribe tu correo electrónico.');
    else if (!EMAIL_RE.test(email)) mal('rEmail', 'Correo inválido. Ejemplo: nombre@correo.com');
    else if (estado.cuentas[email]) mal('rEmail', 'Este correo ya está registrado. Inicia sesión.');
    const r = requisitos(pass);
    if (!pass) mal('rPass', 'Crea una contraseña.');
    else if (!(r.len && r.may && r.min && r.num)) mal('rPass', 'No cumple los requisitos de la lista.');
    if (!pass2) mal('rPass2', 'Confirma tu contraseña.');
    else if (pass !== pass2) mal('rPass2', 'Las contraseñas no coinciden.');

    if (!ok) { enfocarPrimerError(f); return; }   // conserva lo correcto, no avanza
    estado.cuentas[email] = { cedula, edad, nombres, apellidos, email, pass: await hash(pass) };
    guardar();
    f.reset(); actualizarRequisitos(); actualizarBadgeEdad();
    avisoLogin = { tipo: 'ok', texto: '¡Cuenta creada con éxito! Inicia sesión para ingresar a MediTime.' };
    $('#lEmail').value = email;
    irA('#/login');
  });

  /* ---------- LOGIN ---------- */
  function mostrarAvisoLogin() {
    const a = $('#alertaLogin');
    if (!avisoLogin) { a.className = 'd-none'; a.textContent = ''; return; }
    a.className = avisoLogin.tipo === 'ok' ? 'mt-alerta-ok' : 'mt-alerta-error';
    a.textContent = avisoLogin.texto; avisoLogin = null;
  }
  $('#formLogin').addEventListener('submit', async e => {
    e.preventDefault();
    const f = e.target; limpiarErrores(f);
    const email = $('#lEmail').value.trim().toLowerCase(), pass = $('#lPass').value;
    let ok = true; const mal = (id, m) => { setError($('#' + id), m); ok = false; };
    if (!email) mal('lEmail', 'Escribe tu correo electrónico.');
    else if (!EMAIL_RE.test(email)) mal('lEmail', 'Correo inválido. Ejemplo: nombre@correo.com');
    if (!pass) mal('lPass', 'Escribe tu contraseña.');
    if (!ok) { enfocarPrimerError(f); return; }
    const c = estado.cuentas[email];
    if (!c) { setError($('#lEmail'), 'Correo no registrado.'); $('#lEmail').focus(); return; }
    if ((await hash(pass)) !== c.pass) { setError($('#lPass'), 'La contraseña ingresada es incorrecta.'); $('#lPass').focus(); return; }
    estado.sesion = email; guardar();
    f.reset();
    aplicarModoEdad(c.edad);
    activarAudio();                // el clic de ingreso es el gesto que desbloquea el audio
    iniciarSegundoPlano();
    pedirWakeLock();
    irA('#/hoy');
    revisar();
  });

  /* Mostrar/ocultar contraseña */
  document.addEventListener('click', e => {
    const b = e.target.closest('[data-ojo]'); if (!b) return;
    const i = document.getElementById(b.dataset.ojo);
    const ver = i.type === 'password'; i.type = ver ? 'text' : 'password'; b.textContent = ver ? 'Ocultar' : 'Ver';
  });

  /* ---------- HOY ---------- */
  let firmaHoy = '';
  function filaDosis(d, fecha, mostrarFecha = false) {
    const est = estadoDosis(d, fecha);
    const tom = tomada(d, fecha);
    return `<div class="mt-dosis" data-id="${esc(d.id)}">
      <div class="d-flex justify-content-between align-items-start gap-2">
        <div>
          <div class="mt-dosis-nombre">${esc(d.nombre)}</div>
          <div class="small mt-muted">${esc(d.dosis)} · ${esc(d.condicion)}${d.repetir === 'diaria' ? ' · Todos los días' : ''}</div>
        </div>
        <div class="text-end"><div class="mt-dosis-hora">${esc(d.hora)}</div><span class="mt-estado est-${est}">${ETIQUETA[est]}</span></div>
      </div>
      <div class="d-flex gap-2 mt-2 flex-wrap">
        ${tom ? `<span class="small mt-muted align-self-center">Tomada a las ${esc(tom)}</span>` :
          `<button type="button" class="btn btn-mt btn-sm" data-accion="tomar" data-id="${esc(d.id)}" data-fecha="${fecha}">✓ Tomar ahora</button>`}
        <button type="button" class="btn btn-peligro btn-sm ms-auto" data-accion="eliminar" data-id="${esc(d.id)}" aria-label="Eliminar recordatorio de ${esc(d.nombre)}">Eliminar</button>
      </div>
    </div>`;
  }
  function renderHoy() {
    const c = estado.cuentas[estado.sesion]; if (!c) return;
    const ahora = new Date(), hoy = ymd(ahora);
    $('#hNombre').textContent = `${c.nombres} ${c.apellidos}`;
    $('#hFecha').textContent = fechaLarga(ahora);

    // Semana actual (lunes a domingo)
    const lun = new Date(ahora); lun.setDate(ahora.getDate() - ((ahora.getDay() + 6) % 7));
    let sem = '';
    for (let i = 0; i < 7; i++) {
      const d = new Date(lun); d.setDate(lun.getDate() + i);
      const es = ymd(d) === hoy;
      sem += `<button type="button" class="mt-sem-dia${es ? ' hoy' : ''}" data-accion="ir-dia" data-fecha="${ymd(d)}" aria-label="${fechaLarga(d)}"${es ? ' aria-current="date"' : ''}><small>${DIAS_CORTO[i]}</small>${pad(d.getDate())}${es ? '<span class="tag-hoy">HOY</span>' : ''}</button>`;
    }
    $('#semana').innerHTML = sem;

    const lista = dosisDe(hoy);
    const hechas = lista.filter(d => tomada(d, hoy)).length;
    const pct = lista.length ? Math.round(hechas / lista.length * 100) : 0;
    firmaHoy = lista.map(d => d.id + estadoDosis(d, hoy)).join(',');

    // Progreso
    if (!lista.length) $('#hProgreso').innerHTML = '';
    else $('#hProgreso').innerHTML = `<div class="${pct === 100 ? 'mt-alerta-ok' : 'mt-sub'} mb-0">
        <div class="d-flex justify-content-between mb-1"><strong>${pct === 100 ? '¡Tratamiento de hoy al 100%!' : 'Avance de hoy'}</strong><span>${hechas} de ${lista.length}</span></div>
        <div class="mt-progreso" role="progressbar" aria-valuenow="${pct}" aria-valuemin="0" aria-valuemax="100" aria-label="Avance del tratamiento de hoy"><div style="width:${pct}%"></div></div></div>`;

    // Próxima toma
    const prox = lista.find(d => !tomada(d, hoy));
    $('#hProxima').innerHTML = prox
      ? `<p class="mt-eyebrow text-start mb-1">PRÓXIMA TOMA</p>${filaDosis(prox, hoy).replace('class="mt-dosis"', 'class="mt-dosis proxima"')}` : '';

    // Lista completa
    $('#hLista').innerHTML = lista.length
      ? lista.map(d => filaDosis(d, hoy)).join('')
      : '<div class="mt-vacio">No tienes medicamentos programados para hoy.<br><span class="small">Pulsa «Programar nuevo medicamento» para empezar.</span></div>';
  }

  /* ---------- CALENDARIO ---------- */
  let calMes = (() => { const d = new Date(); return new Date(d.getFullYear(), d.getMonth(), 1); })();
  let calSel = ymd(new Date());
  function renderCalendario() {
    $('#calTitulo').textContent = `${MESES[calMes.getMonth()]} ${calMes.getFullYear()}`;
    const hoy = ymd(new Date());
    const primero = (calMes.getDay() + 6) % 7;
    const dias = new Date(calMes.getFullYear(), calMes.getMonth() + 1, 0).getDate();
    let h = DIAS_CORTO.map(n => `<div class="mt-cal-cab">${n}</div>`).join('');
    for (let i = 0; i < primero; i++) h += '<div aria-hidden="true"></div>';
    for (let n = 1; n <= dias; n++) {
      const f = `${calMes.getFullYear()}-${pad(calMes.getMonth() + 1)}-${pad(n)}`;
      const ds = dosisDe(f); let punto = '', resumen = 'sin dosis';
      if (ds.length) {
        const ests = ds.map(d => estadoDosis(d, f));
        if (ests.every(x => x === 'tomada')) { punto = 'p-verde'; resumen = 'todas las dosis tomadas'; }
        else if (ests.some(x => x === 'atrasada' || x === 'omitida')) { punto = 'p-rojo'; resumen = 'hay dosis atrasadas u omitidas'; }
        else { punto = 'p-ambar'; resumen = 'dosis pendientes'; }
      }
      h += `<button type="button" class="mt-dia${f === hoy ? ' hoy' : ''}${f === calSel ? ' sel' : ''}" data-accion="sel-dia" data-fecha="${f}" aria-label="${n} de ${MESES[calMes.getMonth()]}, ${resumen}"${f === calSel ? ' aria-pressed="true"' : ''}>${n}${punto ? `<span class="mt-punto ${punto}"></span>` : ''}</button>`;
    }
    $('#calGrid').innerHTML = h;
    const sel = parseYmd(calSel), ds = dosisDe(calSel);
    $('#calDetalle').innerHTML = `<div class="d-flex justify-content-between align-items-center mb-2">
        <h2 class="mt-h2 mb-0">Dosis del ${sel.getDate()} de ${MESES[sel.getMonth()]} ${sel.getFullYear()}</h2>
        ${calSel === hoy ? '<span class="mt-estado est-pendiente">Hoy en curso</span>' : ''}</div>
      ${ds.length ? ds.map(d => filaDosis(d, calSel)).join('') : '<div class="mt-vacio">No hay dosis programadas para esta fecha.</div>'}
      <div class="d-grid mt-2"><button type="button" class="btn btn-mt-sec" data-accion="nuevo" data-fecha="${calSel}">+ Programar dosis para esta fecha</button></div>`;
  }

  /* ---------- NUEVO RECORDATORIO ---------- */
  const modalDosis = new bootstrap.Modal('#modalDosis');
  function abrirNuevo(fecha) {
    const f = $('#formDosis'); f.reset(); limpiarErrores(f);
    const hoy = ymd(new Date());
    $('#dFecha').min = hoy;
    $('#dFecha').value = fecha && fecha >= hoy ? fecha : hoy;
    modalDosis.show();
  }
  $('#modalDosis').addEventListener('shown.bs.modal', () => $('#dNombre').focus());
  $('#formDosis').addEventListener('submit', e => {
    e.preventDefault();
    const f = e.target; limpiarErrores(f);
    const nombre = $('#dNombre').value.trim(), dosis = $('#dDosis').value.trim(), fecha = $('#dFecha').value, hora = $('#dHora').value;
    let ok = true; const mal = (id, m) => { setError($('#' + id), m); ok = false; };
    const ahora = new Date(), hoy = ymd(ahora);
    if (!nombre) mal('dNombre', 'Escribe el nombre del medicamento. Ej: Paracetamol');
    else if (nombre.length < 2) mal('dNombre', 'El nombre es muy corto.');
    if (!dosis) mal('dDosis', 'Escribe la dosis. Ej: 500 mg, 1 tableta');
    if (!fecha) mal('dFecha', 'Elige una fecha.');
    else if (fecha < hoy) mal('dFecha', 'La fecha no puede estar en el pasado.');
    if (!hora) mal('dHora', 'Elige la hora exacta de la toma.');
    else if (fecha === hoy && hora <= hm(ahora)) mal('dHora', 'Esa hora ya pasó. Elige una hora futura.');
    if (!ok) { enfocarPrimerError(f); return; }
    dosisUsuario().push({ id: Date.now().toString(36) + Math.random().toString(36).slice(2, 5), nombre, dosis, fecha, hora, repetir: $('#dRepetir').value, condicion: $('#dCondicion').value });
    guardar();
    modalDosis.hide();
    toast('Medicamento programado correctamente.');
    activarAudio(); iniciarSegundoPlano();
    if ('Notification' in window && Notification.permission === 'default') Notification.requestPermission().then(renderAjustes);
    renderVista();
  });

  /* ---------- Confirmaciones (tomar / eliminar) ---------- */
  const modalConf = new bootstrap.Modal('#modalConfirmar');
  let accionConf = null;
  function confirmar(titulo, texto, botonTxt, fn) {
    $('#cTitulo').textContent = titulo; $('#cTexto').textContent = texto; $('#cAceptar').textContent = botonTxt;
    accionConf = fn; modalConf.show();
  }
  $('#cAceptar').addEventListener('click', () => { const fn = accionConf; accionConf = null; modalConf.hide(); if (fn) fn(); });

  function registrarToma(id, fecha) {
    tomasUsuario()[id + '|' + fecha] = hm(new Date());
    delete estado.posp[id + '|' + fecha]; guardar();
    toast('¡Toma registrada exitosamente!');
    renderVista();
  }
  function pedirToma(id, fecha) {
    const d = dosisUsuario().find(x => x.id === id); if (!d) return;
    confirmar('Confirmar toma', `¿Confirmas que has tomado ${d.nombre} (${d.dosis}) correspondiente a las ${d.hora}?`, 'Sí, registrar', () => registrarToma(id, fecha));
  }
  function pedirEliminar(id) {
    const d = dosisUsuario().find(x => x.id === id); if (!d) return;
    confirmar('Eliminar recordatorio', `Se eliminará «${d.nombre}» de ${d.hora}${d.repetir === 'diaria' ? ' y todas sus repeticiones' : ''}.`, 'Sí, eliminar', () => {
      estado.dosis[estado.sesion] = dosisUsuario().filter(x => x.id !== id); guardar();
      toast('Recordatorio eliminado.'); renderVista();
    });
  }

  /* ---------- Audio / alarma ---------- */
  let ctx = null, timbre = null, keep = null, alarmaActual = null, wl = null;
  function audioCtx() {
    if (!ctx) { const AC = window.AudioContext || window.webkitAudioContext; if (!AC) return null; ctx = new AC(); }
    return ctx;
  }
  async function activarAudio() {
    const c = audioCtx();
    if (c && c.state !== 'running') { try { await c.resume(); } catch (_) { /* requiere gesto */ } }
    actualizarAvisoAudio();
    return !!c && c.state === 'running';
  }
  function actualizarAvisoAudio() {
    const ver = !!estado.sesion && rutaActual === 'hoy' && (!ctx || ctx.state !== 'running');
    $('#avisoAudio').classList.toggle('d-none', !ver);
    const ea = $('#estadoAudio');
    if (ea) ea.textContent = ctx && ctx.state === 'running' ? '✓ Sonido activo.' : 'Sonido aún sin activar en esta sesión.';
  }
  function bip() {
    const c = audioCtx(); if (!c || c.state !== 'running') return;
    const t = c.currentTime;
    [[0, 880], [0.25, 1175], [0.5, 880]].forEach(([off, fr]) => {
      const o = c.createOscillator(), g = c.createGain();
      o.type = 'square'; o.frequency.value = fr;
      g.gain.setValueAtTime(0.0001, t + off);
      g.gain.exponentialRampToValueAtTime(0.3, t + off + 0.02);
      g.gain.exponentialRampToValueAtTime(0.0001, t + off + 0.2);
      o.connect(g); g.connect(c.destination); o.start(t + off); o.stop(t + off + 0.22);
    });
    if (navigator.vibrate) navigator.vibrate([300, 150, 300]);
  }
  async function iniciarSonido() {
    detenerSonido();
    await activarAudio();
    bip(); timbre = setInterval(bip, 1500);
  }
  function detenerSonido() { if (timbre) { clearInterval(timbre); timbre = null; } if (navigator.vibrate) navigator.vibrate(0); }

  // Oscilador casi inaudible para que el navegador no suspenda la pestaña en segundo plano
  function iniciarSegundoPlano() {
    if (!estado.ajustes.segundoPlano || keep) return;
    const c = audioCtx(); if (!c) return;
    try {
      const o = c.createOscillator(), g = c.createGain();
      o.frequency.value = 40; g.gain.value = 0.0008; o.connect(g); g.connect(c.destination); o.start();
      keep = o;
    } catch (_) { /* ignorar */ }
  }
  function detenerSegundoPlano() { if (keep) { try { keep.stop(); } catch (_) { /* ignorar */ } keep = null; } }

  async function pedirWakeLock() {
    if (!estado.sesion || !estado.ajustes.pantalla || !('wakeLock' in navigator) || wl) return;
    try { wl = await navigator.wakeLock.request('screen'); wl.addEventListener('release', () => { wl = null; }); } catch (_) { /* no disponible */ }
  }
  function soltarWakeLock() { if (wl) { wl.release().catch(() => { }); wl = null; } }

  async function notificar(d) {
    if (!('Notification' in window) || Notification.permission !== 'granted') return;
    const opts = {
      body: `${d.nombre} · ${d.dosis} — ${d.condicion}`, icon: 'icons/icon-192.png', badge: 'icons/icon-192.png',
      tag: 'meditime-' + d.id, renotify: true, requireInteraction: true, vibrate: [300, 150, 300, 150, 300], data: { url: './#/hoy' }
    };
    try {
      const reg = 'serviceWorker' in navigator ? await navigator.serviceWorker.getRegistration() : null;
      if (reg) await reg.showNotification('Hora de tu medicamento', opts); else new Notification('Hora de tu medicamento', opts);
    } catch (_) { /* ignorar */ }
  }

  const modalAlarma = new bootstrap.Modal('#modalAlarma');
  function resetBotonTomar() { $('#aTomar').textContent = 'Ya la tomé'; $('#aConfirmaMsg').classList.add('d-none'); }
  function dispararAlarma(d, fecha) {
    const k = d.id + '|' + fecha;
    estado.alarmadas[k] = 1; delete estado.posp[k]; guardar();
    alarmaActual = { d, fecha, k };
    $('#aNombre').textContent = d.nombre;
    $('#aDetalle').textContent = `${d.dosis} · ${d.condicion}`;
    $('#aHora').textContent = d.hora;
    resetBotonTomar();
    modalAlarma.show();
    iniciarSonido(); notificar(d); renderVista();
    document.title = '⏰ ¡Hora de tu medicamento! · MediTime';
  }
  function cerrarAlarma() {
    detenerSonido(); alarmaActual = null; modalAlarma.hide(); resetBotonTomar();
    document.title = `${TITULOS[rutaActual]} · MediTime`;
  }
  $('#aSilenciar').addEventListener('click', detenerSonido);
  $('#aPosponer').addEventListener('click', () => {
    if (!alarmaActual) return;
    estado.posp[alarmaActual.k] = Date.now() + 5 * 60000; guardar();
    toast('Alarma pospuesta 5 minutos.'); cerrarAlarma(); renderVista();
  });
  $('#aTomar').addEventListener('click', () => {
    if (!alarmaActual) return;
    if ($('#aConfirmaMsg').classList.contains('d-none')) {      // paso 1: pedir confirmación (prevención de errores)
      $('#aConfirmaMsg').classList.remove('d-none'); $('#aTomar').textContent = 'Sí, registrar la toma'; return;
    }
    const { d, fecha } = alarmaActual; cerrarAlarma(); registrarToma(d.id, fecha);
  });

  // Revisa cada segundo si llegó la hora de alguna dosis
  function revisar() {
    if (!estado.sesion || alarmaActual) return;
    const ahora = new Date(), hoy = ymd(ahora), min = ahora.getHours() * 60 + ahora.getMinutes();
    for (const d of dosisDe(hoy)) {
      const k = d.id + '|' + hoy;
      if (tomada(d, hoy)) continue;
      const [h, m] = d.hora.split(':').map(Number), dif = min - (h * 60 + m);
      let debe = false;
      if (estado.posp[k]) { if (Date.now() >= estado.posp[k]) debe = true; }
      else if (dif >= 0 && !estado.alarmadas[k]) {
        if (dif <= 60) debe = true; else { estado.alarmadas[k] = 1; guardar(); } // muy atrasada: solo marcar
      }
      if (debe) { dispararAlarma(d, hoy); return; }
    }
  }
  let ultimoMin = '';
  function tick() {
    const a = new Date();
    const r = $('#reloj'); if (r) r.textContent = `${pad(a.getHours())}:${pad(a.getMinutes())}:${pad(a.getSeconds())}`;
    revisar();
    const m = hm(a);
    if (m !== ultimoMin) {
      ultimoMin = m;
      if (rutaActual === 'hoy' && estado.sesion) {
        const hoy = ymd(a), firma = dosisDe(hoy).map(d => d.id + estadoDosis(d, hoy)).join(',');
        if (firma !== firmaHoy) renderHoy();
      }
    }
  }

  /* ---------- AJUSTES / PWA ---------- */
  let promptInstalar = null;
  function renderAjustes() {
    const n = $('#estadoNotif');
    if (n) n.textContent = !('Notification' in window) ? 'Este navegador no admite notificaciones.'
      : Notification.permission === 'granted' ? '✓ Notificaciones activadas.'
        : Notification.permission === 'denied' ? '✗ Bloqueadas: habilítalas en la configuración del sitio del navegador.' : 'Aún no concedidas.';
    $('#swSegundo').checked = !!estado.ajustes.segundoPlano;
    $('#swPantalla').checked = !!estado.ajustes.pantalla;
    const p = $('#estadoPwa');
    const sw = 'serviceWorker' in navigator && navigator.serviceWorker.controller;
    const inst = window.matchMedia('(display-mode: standalone)').matches || navigator.standalone;
    p.textContent = (inst ? '✓ Ejecutándose como aplicación instalada. ' : 'Ejecutándose en el navegador. ') + (sw ? '✓ Funciona sin conexión (caché activa).' : 'Caché sin conexión aún no activa (recarga una vez desde localhost/HTTPS).');
    actualizarAvisoAudio();
  }
  document.addEventListener('change', e => {
    const a = e.target.dataset && e.target.dataset.ajuste; if (!a) return;
    estado.ajustes[a] = e.target.checked; guardar();
    if (a === 'segundoPlano') e.target.checked ? iniciarSegundoPlano() : detenerSegundoPlano();
    if (a === 'pantalla') e.target.checked ? pedirWakeLock() : soltarWakeLock();
  });
  window.addEventListener('beforeinstallprompt', e => { e.preventDefault(); promptInstalar = e; $$('[data-accion="instalar"]').forEach(b => b.classList.remove('d-none')); });
  window.addEventListener('appinstalled', () => { promptInstalar = null; $$('[data-accion="instalar"]').forEach(b => b.classList.add('d-none')); toast('MediTime instalada correctamente.'); renderAjustes(); });
  function actualizarRed() { $('#estadoRed').classList.toggle('d-none', navigator.onLine); }
  window.addEventListener('online', actualizarRed); window.addEventListener('offline', actualizarRed);

  /* ---------- Delegación de eventos ---------- */
  document.addEventListener('click', async e => {
    const b = e.target.closest('[data-accion]'); if (!b) return;
    const { accion, id, fecha } = b.dataset;
    switch (accion) {
      case 'nuevo': abrirNuevo(fecha); break;
      case 'tomar': pedirToma(id, fecha); break;
      case 'eliminar': pedirEliminar(id); break;
      case 'ir-dia': calSel = fecha; { const d = parseYmd(fecha); calMes = new Date(d.getFullYear(), d.getMonth(), 1); } irA('#/calendario'); break;
      case 'sel-dia': calSel = fecha; renderCalendario(); { const el = $(`.mt-dia[data-fecha="${fecha}"]`); if (el) el.focus(); } break;
      case 'mes-ant': calMes = new Date(calMes.getFullYear(), calMes.getMonth() - 1, 1); renderCalendario(); break;
      case 'mes-sig': calMes = new Date(calMes.getFullYear(), calMes.getMonth() + 1, 1); renderCalendario(); break;
      case 'tema': estado.ajustes.tema = document.documentElement.getAttribute('data-bs-theme') === 'dark' ? 'light' : 'dark'; guardar(); aplicarTema(estado.ajustes.tema); break;
      case 'activar-audio': await activarAudio(); iniciarSegundoPlano(); break;
      case 'probar-sonido': {
        const ok = await activarAudio(); iniciarSegundoPlano();
        if (ok) { bip(); setTimeout(bip, 1500); toast('Probando sonido… ¿lo escuchaste?'); } else toast('No se pudo activar el audio en este navegador.', true);
        break;
      }
      case 'permiso-notif':
        if ('Notification' in window) { await Notification.requestPermission(); renderAjustes(); }
        break;
      case 'instalar':
        if (promptInstalar) { promptInstalar.prompt(); await promptInstalar.userChoice; promptInstalar = null; $$('[data-accion="instalar"]').forEach(x => x.classList.add('d-none')); }
        break;
      case 'salir':
        detenerSonido(); detenerSegundoPlano(); soltarWakeLock(); alarmaActual = null;
        estado.sesion = null; guardar(); aplicarModoEdad(null); irA('#/');
        break;
    }
  });
  // Cualquier toque desbloquea el audio si hay sesión (política de autoplay)
  document.addEventListener('pointerdown', () => { if (estado.sesion && (!ctx || ctx.state !== 'running')) activarAudio(); }, { passive: true });
  document.addEventListener('visibilitychange', () => { if (document.visibilityState === 'visible') { pedirWakeLock(); revisar(); renderVista(); } });
  window.addEventListener('hashchange', ruta);

  /* ---------- Service worker ---------- */
  if ('serviceWorker' in navigator && (location.protocol === 'https:' || ['localhost', '127.0.0.1'].includes(location.hostname))) {
    navigator.serviceWorker.register('service-worker.js').then(() => navigator.serviceWorker.ready).then(renderAjustes).catch(() => { });
    navigator.serviceWorker.addEventListener('controllerchange', renderAjustes);
  }

  /* ---------- Arranque ---------- */
  aplicarTema(estado.ajustes.tema);
  if (estado.sesion && !estado.cuentas[estado.sesion]) estado.sesion = null;
  if (estado.sesion) { aplicarModoEdad(estado.cuentas[estado.sesion].edad); iniciarSegundoPlano(); pedirWakeLock(); } else aplicarModoEdad(null);
  actualizarRed();
  ruta();
  tick();
  setInterval(tick, 1000);
})();
