# MediTime · PWA (Guía Práctica 3, Interacción Hombre-Máquina)

Prototipo académico de alta fidelidad: recordatorio de medicamentos con **alarma sonora**, instalable como app en celular y PC, con funcionamiento **sin conexión**.

Tecnologías: HTML5 semántico, CSS propio, **Bootstrap 5.3 (local en `vendor/`)**, JavaScript. Sin backend, sin base de datos, sin APIs. Datos simulados en `localStorage`.

## Estructura

```
meditime-pwa/
├── index.html               Punto de entrada, vistas (SPA) y navegación
├── css/estilos.css          Guía de estilo y responsive
├── js/app.js                Rutas, validaciones, datos simulados, alarma
├── manifest.webmanifest     Nombre, start_url, display, iconos 192/512
├── service-worker.js        Caché de recursos propios (offline)
├── icons/                   icon-192, icon-512, maskable, apple-touch
├── assets/logo.png          Logotipo y eslogan
├── vendor/bootstrap/        Bootstrap 5.3 local (css + js bundle)
└── README.md
```

## Requisitos y ejecución

Una PWA **no se instala abriendo el HTML con doble clic (`file://`)**. Usa `localhost` o HTTPS:

- **VS Code:** extensión *Live Server* → clic derecho en `index.html` → *Open with Live Server*.
- **Python:** `python -m http.server 8080` dentro de la carpeta → abrir `http://localhost:8080`.
- **Node:** `npx serve .`
- **Publicar gratis (HTTPS, para instalar en el celular):** GitHub Pages o Netlify (arrastrar la carpeta).

## Credenciales simuladas

- Cuenta de prueba: `demo@meditime.com` / `Demo1234`
- O crea la tuya en *Crear cuenta*. **No existe autenticación ni seguridad real**: los datos viven en el navegador del dispositivo.

## Instalación

- **PC (Chrome/Edge):** icono de instalar en la barra de direcciones, o botón «Instalar MediTime» (Inicio y Ajustes).
- **Android (Chrome):** menú ⋮ → *Instalar aplicación*.
- **iPhone (Safari):** Compartir → *Añadir a pantalla de inicio*.

## Prueba sin conexión (P-13)

1. Abre la app una vez con internet (se llena la caché).
2. DevTools → *Application* → *Service Workers* → marca *Offline* (o activa modo avión).
3. Recarga: la app debe abrir con estilos, iconos y funciones completas.

## Cómo funciona la alarma (y sus límites)

- Cada segundo la app compara la hora con tus dosis. Al llegar la hora: ventana de alarma, **sonido repetido (Web Audio)**, vibración, notificación del sistema y opciones *Ya la tomé* (con confirmación), *Posponer 5 min* y *Silenciar*.
- El navegador exige **un toque del usuario** para reproducir audio: se desbloquea al iniciar sesión o con *Activar y probar sonido* (Ajustes).
- Para segundo plano se usa: oscilador casi inaudible (evita que el navegador congele la pestaña), *Wake Lock* (pantalla encendida) y notificaciones.
- **Límite de las PWA:** si el sistema operativo cierra o congela la app (muy común en iPhone y en Android con ahorro de batería), la alarma no puede sonar. Una alarma 100 % fiable requiere notificaciones push desde un servidor o app nativa (fuera del alcance de esta guía). Al reabrir la app, las tomas de la última hora que se perdieron suenan al instante.

## Trazabilidad (SRS del grupo)

| Requisito | Pantalla | Acción funcional | Prueba |
|---|---|---|---|
| RF-01 Registro | 1.2 Registro (#/registro) | Cédula 10 dígitos, edad, nombres, correo y contraseña; «¡Cuenta creada con éxito!» | P-03, P-05, P-06, P-07 |
| RF-02 Requisitos de contraseña en vivo | 1.2 Registro | Lista ✓/✗ y aviso de coincidencia | P-06, P-07 |
| RF-03 Inicio de sesión simulado | 1.3 Login (#/login) | Compara credenciales; bloquea rutas privadas | P-02, P-08 |
| RF-04 Programar dosis | 2.1 Hoy / 2.2 Nuevo recordatorio | «Medicamento programado correctamente.» | P-03, P-09 |
| RF-05 Confirmar toma | 2.1 Hoy / 2.3 Confirmar toma | «¡Toma registrada exitosamente!» y avance diario | P-02, P-04 |
| RF-06 Calendario mensual | 2.4 Calendario (#/calendario) | Punto verde/ámbar/rojo y detalle del día | P-01, P-03 |
| UX-01 Tema oscuro | Todas | Variables CSS (#090D16 / #131B2E) | P-14 |
| UX-02 Legibilidad por edad | Registro | Indicador 10-30 / 31-59 / 60+ | P-07, P-14 |
| UX-03 Teclado y foco | Todas | Foco celeste visible | P-11 |
| UX-04 Errores junto al campo | Registro, Login, Nuevo recordatorio | Mensaje específico en rojo | P-05, P-06, P-08 |
| UX-05 Confirmación | Confirmar toma | «Sí, registrar» / «Cancelar» | P-04 |
| UX-06 Mobile-first | Todas | Rejilla Bootstrap 390 / 768 / 1280 px | P-10 |

Extra no exigido por el SRS: alarma sonora (Web Audio) y pantalla Ajustes.

## Diferencias frente a un sistema productivo

Contraseñas con hash SHA-256 sin sal en `localStorage` (solo demostración); sin sincronización entre dispositivos; sin push desde servidor; alarmas dependientes de que el sistema mantenga la app viva.
